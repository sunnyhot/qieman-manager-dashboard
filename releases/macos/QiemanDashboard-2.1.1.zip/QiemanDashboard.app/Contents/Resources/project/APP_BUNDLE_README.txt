This app bundle contains a copy of the Python project files.

Runtime data location:
~/Library/Application Support/QiemanDashboard

Put your login cookie here if needed:
~/Library/Application Support/QiemanDashboard/qieman.cookie

The bundled app also ships with snapshot backups from the legacy web dashboard.
